package com.example.projectuas

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class Login :  AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val edt_email: EditText = findViewById(R.id.edt_email)
        val edt_password: EditText = findViewById(R.id.edt_password)
        val btn_login: LinearLayout = findViewById(R.id.btn_login)

        btn_login.setOnClickListener {
            val isi_email:String = edt_email.text.toString()
            val isi_password:String = edt_password.text.toString()

            val dbrudeboy: SQLiteDatabase = openOrCreateDatabase("rudeboy", MODE_PRIVATE, null)

            val query = dbrudeboy.rawQuery("SELECT * FROM admin WHERE admin_email='$isi_email' AND admin_password='$isi_password'", null)
            val cek = query.moveToNext()

            if (cek)
            {
                val id = query.getString(0)
                val nama = query.getString(1)
                val email = query.getString(2)
                val password = query.getString(3)
                val namaLengkap = query.getString(4)

                val session:SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
                val masuk = session.edit()
                masuk.putString("admin_id", id)
                masuk.putString("admin_nama", nama)
                masuk.putString("admin_email", email)
                masuk.putString("admin_password", password)
                masuk.putString("admin_namaLengkap", namaLengkap)
                masuk.commit()

                val pindah: Intent = Intent(this, Produk_baju::class.java)
                startActivity(pindah)

            } else {
                Toast.makeText(this, "Email atau Password anda Salah DULLL!!!!", Toast.LENGTH_LONG).show()
            }
        }
    }
}