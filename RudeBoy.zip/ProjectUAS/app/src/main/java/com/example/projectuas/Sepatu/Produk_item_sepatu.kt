package com.example.projectuas.Sepatu

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.projectuas.R

class Produk_item_sepatu(
    val ini: Context,
    val id: MutableList<String>,
    val merek: MutableList<String>,
    val keterangan: MutableList<String>,
    val harga: MutableList<String>,
    val foto: MutableList<Bitmap>
) : RecyclerView.Adapter<Produk_item_sepatu.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.produk_item_sepatu, parent, false)
        return ViewHolder(view)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val produk_foto: ImageView = itemView.findViewById(R.id.produk_foto)
        val txt_merek: TextView = itemView.findViewById(R.id.txt_merek)
        val txt_keterangan: TextView = itemView.findViewById(R.id.txt_keterangan)
        val txt_harga: TextView = itemView.findViewById(R.id.txt_harga)
        val btnUbah: TextView = itemView.findViewById(R.id.btnUbah)
        val btn_hapus: TextView = itemView.findViewById(R.id.btn_hapus)
    }

    override fun getItemCount(): Int {
        return merek.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_merek.text = merek[position]
        holder.txt_keterangan.text = keterangan[position]
        holder.txt_harga.text = harga[position]
        holder.produk_foto.setImageBitmap(foto[position])

        holder.btn_hapus.setOnClickListener {
            val id_sepatu_terpilih: String = id[position]
            val pindah: Intent = Intent(ini, Produk_hapus_sepatu::class.java)
            pindah.putExtra("id_sepatu_terpilih", id_sepatu_terpilih)
            ini.startActivity(pindah)
        }

        holder.btnUbah.setOnClickListener {
            val id_sepatu_terpilih: String = id[position]
            val pindah: Intent = Intent(ini, Produk_ubah_sepatu::class.java)
            pindah.putExtra("id_sepatu_terpilih", id_sepatu_terpilih)
            ini.startActivity(pindah)
        }
    }
}