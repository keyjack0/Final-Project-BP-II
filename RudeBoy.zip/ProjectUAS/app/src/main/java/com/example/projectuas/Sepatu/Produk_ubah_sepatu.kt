package com.example.projectuas.Sepatu

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.example.projectuas.Produk_baju
import com.example.projectuas.R
import org.w3c.dom.Text
import java.io.ByteArrayOutputStream

class Produk_ubah_sepatu : AppCompatActivity() {

    var urlgambar: String? = null
    var bitmapgambar: Bitmap? = null
    var iv_foto: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_ubah_sepatu)

        val id_sepatu_terpilih: String = intent.getStringExtra("id_sepatu_terpilih").toString()

        val dbrudeboy: SQLiteDatabase = openOrCreateDatabase("rudeboy", MODE_PRIVATE, null)
        val ubah = dbrudeboy.rawQuery("SELECT * FROM sepatu WHERE id ='$id_sepatu_terpilih' ", null)
        ubah.moveToNext()

        if (ubah.moveToFirst()) {
            val edit_merek: EditText = findViewById(R.id.edit_produk)
            val edit_keterangan: EditText = findViewById(R.id.edit_keterangan)
            val edit_harga: EditText = findViewById(R.id.edit_harga)
            val btn_ganti: TextView = findViewById(R.id.btn_ganti)
            val btn_kembali: TextView = findViewById(R.id.btn_kembali)
            iv_foto = findViewById(R.id.iv_foto)

            val ubah_merek: String = ubah.getString(2)
            val ubah_keterangan: String = ubah.getString(3)
            val ubah_harga: String = ubah.getString(4)
            val isi_foto: ByteArray = ubah.getBlob(1)

            edit_merek.setText(ubah_merek)
            edit_keterangan.setText(ubah_keterangan)
            edit_harga.setText(ubah_harga)

            try {
                val gambarbitmap = BitmapFactory.decodeByteArray(isi_foto, 0, isi_foto.size)
                iv_foto?.setImageBitmap(gambarbitmap)
            } catch (e: Exception) {
                val gambarbitmap = BitmapFactory.decodeResource(
                    this.resources,
                    R.drawable.noimage
                )
                iv_foto?.setImageBitmap(gambarbitmap)
            }

            iv_foto?.setOnClickListener {
                val bukagaleri: Intent =
                    Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
                pilihgambar.launch(bukagaleri)
            }

            btn_ganti.setOnClickListener {
                val merek_baru: String = edit_merek.text.toString()
                val keterangan_baru: String = edit_keterangan.text.toString()
                val harga_baru: String = edit_harga.text.toString()

                if (bitmapgambar != null) {
                    val bos = ByteArrayOutputStream()
                    bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100, bos)
                    val bytearraygambar = bos.toByteArray()

                    // Gunakan parameter baru yang sudah diubah
                    val sql =
                        "UPDATE sepatu SET merek=?, keterangan=?, harga=?, foto=? WHERE id='$id_sepatu_terpilih'"
                    val statement = dbrudeboy.compileStatement(sql)
                    statement.clearBindings()
                    statement.bindString(1, merek_baru)
                    statement.bindString(2, keterangan_baru)
                    statement.bindString(3, harga_baru)
                    statement.bindBlob(4, bytearraygambar)
                    statement.executeUpdateDelete()

                    // Setelah berhasil diupdate, kembali ke halaman Produk_baju
                    val pindah: Intent = Intent(this, Produk_sepatu::class.java)
                    startActivity(pindah)
                    finish()  // Tambahkan finish() untuk menutup halaman ini setelah pindah
                } else {

                    val pilihgambar =
                        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                            if (it.resultCode== Activity.RESULT_OK) {
                                val gambardiperoleh = it.data

                                if (gambardiperoleh != null) {
                                    urlgambar = gambardiperoleh.data.toString()
                                    bitmapgambar =
                                        MediaStore.Images.Media.getBitmap(contentResolver, gambardiperoleh.data)
                                    iv_foto?.setImageBitmap(bitmapgambar)
                                }
                            }
                        }
                }
            }

            btn_kembali.setOnClickListener {
                val pindah:Intent = Intent(this, Produk_sepatu::class.java)
                startActivity(pindah)
            }
        }
    }

    private val pilihgambar =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                val gambardiperoleh = it.data
                if (gambardiperoleh != null) {
                    urlgambar = gambardiperoleh.data.toString()
                    bitmapgambar =
                        MediaStore.Images.Media.getBitmap(contentResolver, gambardiperoleh.data)
                    iv_foto?.setImageBitmap(bitmapgambar)
                }
            }
        }
}