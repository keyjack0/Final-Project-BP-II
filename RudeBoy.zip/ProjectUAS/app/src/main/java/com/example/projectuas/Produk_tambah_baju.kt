package com.example.projectuas

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import com.example.projectuas.R
import java.io.ByteArrayOutputStream
import kotlin.jvm.internal.Ref.ByteRef

class Produk_tambah_baju : AppCompatActivity() {
    var urlgambar:Uri?=null
    var bitmapgambar:Bitmap?=null
    var iv_foto:ImageView?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_tambah_baju)

        val edit_produk:EditText = findViewById(R.id.edit_produk)
        val edit_keterangn:EditText = findViewById(R.id.edit_keterangan)
        val edit_harga:EditText = findViewById(R.id.edit_harga)
        val btn_save:TextView = findViewById(R.id.btn_save)
        val btn_kembali:TextView = findViewById(R.id.btn_kembali)
        iv_foto = findViewById(R.id.iv_foto)

        iv_foto?.setOnClickListener {
            val bukagaleri:Intent=Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            pilihgambar.launch(bukagaleri)
        }

        btn_save.setOnClickListener {

            val isi_produk:String = edit_produk.text.toString()
            val isi_keterangan:String = edit_keterangn.text.toString()
            val isi_harga:String = edit_harga.text.toString()


            val bos = ByteArrayOutputStream()
            bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100, bos)
            val bytearraygambar = bos.toByteArray()

            val dbrudeboy:SQLiteDatabase = openOrCreateDatabase("rudeboy", MODE_PRIVATE, null)
            val sql = "INSERT INTO baju (merek, keterangan, harga, foto) VALUES (?,?,?,?)"
            val statement = dbrudeboy.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1, isi_produk)
            statement.bindString(2, isi_keterangan)
            statement.bindString(3, isi_harga)
            statement.bindBlob(4, bytearraygambar)
            statement.executeInsert()

            val pindah:Intent = Intent(this, Produk_baju::class.java)
            startActivity(pindah)
            }

        btn_kembali.setOnClickListener {
            val pindah:Intent = Intent(this, Produk_baju::class.java)
            startActivity(pindah)
        }

        }

        val pilihgambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode==Activity.RESULT_OK) {
                val gambardiperoleh = it.data

                if (gambardiperoleh!=null) {
                    urlgambar = gambardiperoleh.data


                    bitmapgambar = MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
                    iv_foto?.setImageBitmap(bitmapgambar)
                }
            }

        }

}