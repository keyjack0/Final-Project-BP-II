package com.example.projectuas.Celana

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.projectuas.R

class Produk_hapus_celana : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_hapus_celana)

        val id_celana_terpilih:String = intent.getStringExtra("id_celana_terpilih").toString()

        val dbrudeboy: SQLiteDatabase = openOrCreateDatabase("rudeboy", MODE_PRIVATE, null)
        val query = dbrudeboy.rawQuery("DELETE FROM celana WHERE id='$id_celana_terpilih'", null)
        query.moveToNext()

        val pindah: Intent = Intent(this, Produk_celana::class.java)
        startActivity(pindah)
    }
}