package com.example.projectuas

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.w3c.dom.Text

class Profil_admin : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profil_admin)

        val txt_email:TextView  = findViewById(R.id.txt_email)
        val txt_namaLengkap:TextView  = findViewById(R.id.txt_namaLengkap)
        val txt_username:TextView  = findViewById(R.id.txt_username)

        val tampil:SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
        val email:String = tampil.getString("admin_email",null).toString()
        val namaLenkap:String = tampil.getString("admin_namaLengkap",null).toString()
        val nama:String = tampil.getString("admin_nama",null).toString()
        txt_email.text = email
        txt_namaLengkap.text = namaLenkap
        txt_username.text = nama





        val btn_logout: LinearLayout = findViewById(R.id.btn_logout)
        btn_logout.setOnClickListener {
            val pindah: Intent = Intent(this,Login::class.java)
            startActivity(pindah)
        }

        val btn_kembali: TextView =  findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah: Intent = Intent(this,Produk_baju::class.java)
            startActivity(pindah)
        }
    }
}
