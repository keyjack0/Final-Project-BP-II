package com.example.projectuas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Profil_item_admin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profil_item_admin)
    }
}