package com.example.projectuas

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projectuas.Sepatu.Produk_sepatu
import java.io.ByteArrayInputStream

class Produk_baju : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_baju)

        val rv_baju: RecyclerView = findViewById(R.id.rv_baju)

        val id: MutableList<String> = mutableListOf()
        val foto: MutableList<Bitmap> = mutableListOf()
        val merek: MutableList<String> = mutableListOf()
        val keterangan: MutableList<String> = mutableListOf()
        val harga: MutableList<String> = mutableListOf()

        val dbrudeboy: SQLiteDatabase = openOrCreateDatabase("rudeboy", MODE_PRIVATE, null)
        val tampilproduk = dbrudeboy.rawQuery("SELECT * FROM baju", null)
        while (tampilproduk.moveToNext()) {

            try {
                val bis = ByteArrayInputStream(tampilproduk.getBlob(1))
                val gambarbitmap:Bitmap =BitmapFactory.decodeStream(bis)
                foto.add(gambarbitmap)
            } catch (e:Exception) {
                val gambarbitmap:Bitmap =BitmapFactory.decodeResource(this.resources,R.drawable.noimage)
                foto.add(gambarbitmap)
            }

            id.add(tampilproduk.getString(0))
            merek.add(tampilproduk.getString(2))
            keterangan.add(tampilproduk.getString(3))
            harga.add(tampilproduk.getString(4))

        }
        val pbi = Produk_item_baju(this, id, merek, keterangan, harga, foto)

        rv_baju.adapter = pbi
        rv_baju.layoutManager = GridLayoutManager(this, 1)

        val btn_tambah: ImageView = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah: Intent = Intent(this, Produk_tambah_baju::class.java)
            startActivity(pindah)
        }

        val btn_pria: TextView = findViewById(R.id.btn_pria)
        btn_pria.setOnClickListener {
            val pindah: Intent = Intent(this, Produk_baju::class.java)
            startActivity(pindah)
        }

        val btn_wanita: TextView = findViewById(R.id.btn_wanita)
        btn_wanita.setOnClickListener {
            val pindah: Intent = Intent(this, com.example.projectuas.Celana.Produk_celana::class.java)
            startActivity(pindah)
        }

        val btn_anak: TextView = findViewById(R.id.btn_anak)
        btn_anak.setOnClickListener {
            val pindah: Intent = Intent(this, Produk_sepatu::class.java)
            startActivity(pindah)
        }

        val btn_user: ImageView = findViewById(R.id.btn_user)
        btn_user.setOnClickListener {
            val pindah: Intent = Intent(this,Profil_admin::class.java)
            startActivity(pindah)
        }

        }
    }
